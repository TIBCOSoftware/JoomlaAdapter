<?php

defined('_JEXEC') or die;

class SeeddataController extends JControllerLegacy {

    public function display($cachable = false, $urlparams = false) {

        $view = JFactory::getApplication()->input->getCmd('view', 'seeddata');
        JFactory::getApplication()->input->set('view', $view);

        parent::display($cachable, $urlparams);

        return $this;
    }

}

