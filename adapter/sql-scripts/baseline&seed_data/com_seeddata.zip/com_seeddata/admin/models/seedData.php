<?php

defined('_JEXEC') or die;

jimport('joomla.application.component.modellist');

/**
 * Methods supporting a list of Plans records.
 */
class SeeddataModelSeeddata extends JModelList {
    
}
