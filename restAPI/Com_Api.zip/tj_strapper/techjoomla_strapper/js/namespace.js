if(typeof(techjoomla) == 'undefined') {
	var techjoomla = {};
}
if(typeof(techjoomla.jQuery) == 'undefined') {
	techjoomla.jQuery = jQuery.noConflict();
}
