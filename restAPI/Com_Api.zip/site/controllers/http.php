<?php
/**
 * @package	API
 * @version 1.5
 * @author 	Brian Edgerton
 * @link 	http://www.edgewebworks.com
 * @copyright Copyright (C) 2011 Edge Web Works, LLC. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
*/

defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.application.component.controller');
jimport('joomla.plugin.helper');

class ApiControllerHttp extends ApiController
{
	public function __construct( $config = array() )
	{
		parent::__construct( $config );
	}

	public function display( $cachable = false, $urlparams = array() )
	{
		$this->resetDocumentType();
		$app = JFactory::getApplication();
		//$name = $app->input->get('app','','CMD');
		
		$name= "webservices";
		/*
		// Do Some URL shaping Here
		echo var_export( $_SERVER['REQUEST_URI']);
		//$thes = '5';
		//var_dump(parse_url($url));
		
		//$file = 'C:\Users\ddella\Desktop\newfile.txt';
		// Append a new person to the file
		//$current = var_export($thes);
		// Write the contents back to the file
		//file_put_contents($file, $current);
		
// check for https
$protocol = !empty($_SERVER['HTTPS']) ? 'https://' : 'http://';
// sets the full address
$url = $protocol. $_SERVER['HTTP_HOST']. $_SERVER['REQUEST_URI'];

echo $url;
		
		$file = 'C:\Users\ddella\Desktop\newfile2.txt';
		// Open the file to get existing content
		$current = file_get_contents($file);
		// Append a new person to the file
		$current .= var_export($thes);
		// Write the contents back to the file
		file_put_contents($file, $current);
		
		*/
		//$name = $app->input->get('app','','CMD');
		
		
		
		try {
			echo ApiPlugin::getInstance( $name )->fetchResource();

		}  catch ( Exception $e ) {
			echo $this->sendError( $e );
		}
	}

	private function sendError( $exception )
	{
		JResponse::setHeader( 'status', $exception->getCode() );
		$error = new APIException( $exception->getMessage(), $exception->getCode() );
		JFactory::getDocument()->setMimeEncoding( 'application/json' );
		return json_encode( $error->toArray() );
	}

	/**
	 * Resets the document type to format=raw
	 *
	 * @return void
	 * @since 0.1
	 * @todo Figure out if there is a better way to do this
	 */
	private function resetDocumentType()
	{
		JResponse::clearHeaders();
	}
}
