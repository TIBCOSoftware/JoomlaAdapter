<?php
// Just as a place holder to include the correct helper file
require_once JPATH_ADMINISTRATOR.'/components/com_menus/helpers/menus.php';