<?php

// This is the "API" / Application Interface for the APIX Project
//

//Includes

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controllerform');
jimport('joomla.user.authentication');
jimport('joomla.application.component.controller');
jimport('joomla.application.component.model');

require_once JPATH_ROOT . '\components\com_cobalt\controllers\form.php';
require_once JPATH_ROOT . '\components\com_cobalt\controllers\files.php';
require_once JPATH_ROOT . '\components\com_cobalt\controllers\records.php';
require_once JPATH_ROOT . '\libraries\joomla\session\session.php';
require_once JPATH_ROOT . '/components/com_cobalt/api.php';
require_once JPATH_ROOT . '\components\com_cobalt\models\form.php';
require_once JPATH_ROOT . '\components\com_cobalt\controllers\ajaxmore.php';
require_once JPATH_ROOT . '/libraries/legacy/model/legacy.php';
require_once JPATH_ROOT . '\components\com_cobalt\models\records.php';

class WebservicesApiResourcePlans extends ApiResource {


     //Function for making a new record in Cobalt
    public function post() {
        
        //****Saving the Record

        //INstance Cobalt Save controller and Token and Pass it Data
        $controller = new CobaltControllerForm();
        $jinput = JFactory::getApplication()->input;
        
        //Get Var from URLstring
        if (empty($jinput->get('title',"",'CMD'))) {
        $title = 'RandomTitle987654211';
        }
        else{
        $title  = $jinput->get('title',"",'CMD');;
        }

        $_POST['jform']['title'] = $title;
        $_POST['jform']['ucatid'] = '0';
        //Quota Limit
        $_POST['jform']['fields'][80] = "100";
        //Rate Limit
        $_POST['jform']['fields'][79] = "45";
        $_POST['jform']['fields'][55] = "Plan Descript";
        //ID of Product attached to?
        $_POST['jform']['fields'][53] = "1176";
        $_POST['jform']['fields'][39] = '4';
        $_POST['jform']['fields'][37] = 'mandatory desrcipt';
        $_POST['jform']['fields'][131] = 'Plan Type';
        //6 chara keyword or price
        $_POST['jform']['fields'][120] = 'Keywor';

        $_POST['jform']['category']['0'] = '5';
        $_POST['jform']['meta_descr'] = '';
        $_POST['jform']['meta_key'] = '';
        $_POST['jform']['meta_index'] = '';
        $_POST['jform']['alias'] = '';
        $_POST['jform']['ctime'] = date("Y-m-d H:i:s");
        $_POST['jform']['extime'] = '';
        $_POST['jform']['ftime'] = '';
        $_POST['jform']['langs'] = 'en-GB';
        $_POST['jform']['hidden'] = '0';
        $_POST['jform']['featured'] = '0';
        $_POST['jform']['user_id'] = '129';
        $_POST['jform']['archive'] = '0';
        $_POST['jform']['access'] = '1';
        $_POST['jform']['published'] = '1';
        $_POST['jform']['section_id'] = '1';
        $_POST['jform']['type_id'] = '7';
        $_POST['jform']['id'] = '0';
        
        //Login the User This needs to change to Match an exisiting User

        //$auth = & JAuthentication::getInstance();
        //$credentials = array('username' => 'admin34', 'password' => 'admin22');
        //$options = array();
        //$response = $auth->authenticate($credentials, $options);

        //Get Token Name
        $token = JSession::getInstance()->getFormToken($forcenew = true);
        $jinput->post->set($token, '1');
        
        //Asign Post Data to Variable
        $data = JFactory::getApplication()->input->post->get('jform', array(), 'array');
        $jinput->set('jform',$data);
        
        //set save task
        $task = $jinput->get('task', "save", 'STR');
        
        //instantiate the model
        $model = $controller->getModel();
        $form = $model->getForm($emptyarray = array(), true);
          
       //Execute the task 
        $controller->execute($task);
      
    
       $this->plugin->setResponse("Created a New Plan");
    }
    
        ///////////////////////////////
        ///**
	// * @param int    $section_id
	// * @param string $view_what
	// * @param string $order
	// * @param array  $type_ids
	// * @param null   $user_id   No user must be NULL, otherwise 0 would be Guest
	// * @param int    $cat_id
	// * @param int    $limit
	// * @param null   $tpl
	// * @param int    $client    name of the extension that use cobalt records
	// * @param string $client_id ID of the parent cobalt record
	// * @param bool   $lang      true or false. Selects only current language records or records on any language.
	// * @param array  $ids       Ids array of the records.
	// *
	// * @return array
	// */
        //Get
      public function get() {
          
        $api = new CobaltApi();
        $jinput = JFactory::getApplication()->input;
        
        if (empty($jinput->get('limit',"",'CMD'))) {
        $usersetlimit = 20;
        }
        else{
        $usersetlimit = $jinput->get('limit',"",'CMD');
        }
        
        
        $data = $api->records(
	$section_id = 1, 
	$view_what, 
	$orderby, 
	$type_ids = 7,
	$user_id,
	$category_id, 
	$limit = $usersetlimit, 
	$template,
	$client,
	$client_id,
	$lang,
	$ids
            );
            
        printf('Found %d records total', $data['total']);
        
        foreach($data['list'] AS $item) {
        printf('<li><a href="%s">%s</a></li>', $item->url, $item->title); 
        }
        
        //$response = json_encode($data['list']);
        
                                        
        $this->plugin->setResponse($data); // Sends Information to the Browser
     
    }// End Public Function get()
   
    //Function for Deleting a Record From Cobalt
    public function delete() {
        
        $controller = new CobaltControllerRecords();
        $jinput = JFactory::getApplication()->input;
        
        $idtodelete = $jinput->get('id',"",'CMD');
        
        $jinput->set('id',$idtodelete);
        
        if ($controller->delete())
        {
        $response = "Record #{$idtodelete} has been Deleted";
        }
        
        else 
        {
        $response = "Record #{$idtodelete} has not been Deleted For one or more Reasons:"
                . " Record Does not exsist," 
                . " Id is incorrect"
                . " Record could be open elsewhere for editing";    
        }
        
        $this->plugin->setResponse($response);
    }
    
    
    //Function for modifing a record in Cobalt
    public function put() {
        
        $controller = new CobaltControllerForm();
        $jinput = JFactory::getApplication()->input;
        
        
        if (empty($jinput->get('id',"",'CMD'))) {
          
            $this->plugin->setResponse('id param is not set');
        }
        
        else
        {
        $idtoedit = $jinput->get('id',"",'CMD');
        $jinput->set('id',$idtoedit);
        }
        
        $title = $jinput->get('title',"",'CMD');
        
        //Fake Post Data
         $_POST['jform']['title'] = $title;
        $_POST['jform']['ucatid'] = '0';
        //Quota Limit
        $_POST['jform']['fields'][80] = "100";
        //Rate Limit
        $_POST['jform']['fields'][79] = "45";
        $_POST['jform']['fields'][55] = "Plan Descript";
        //ID of Product attached to?
        $_POST['jform']['fields'][53] = "1176";
        $_POST['jform']['fields'][39] = '4';
        $_POST['jform']['fields'][37] = 'mandatory desrcipt';
        $_POST['jform']['fields'][131] = 'Plan Type';
        //6 chara keyword or price
        $_POST['jform']['fields'][120] = 'Keywor';

        $_POST['jform']['category']['0'] = '5';
        $_POST['jform']['meta_descr'] = '';
        $_POST['jform']['meta_key'] = '';
        $_POST['jform']['meta_index'] = '';
        $_POST['jform']['alias'] = '';
        $_POST['jform']['ctime'] = date("Y-m-d H:i:s");
        $_POST['jform']['extime'] = '';
        $_POST['jform']['ftime'] = '';
        $_POST['jform']['langs'] = 'en-GB';
        $_POST['jform']['hidden'] = '0';
        $_POST['jform']['featured'] = '0';
        $_POST['jform']['user_id'] = '129';
        $_POST['jform']['archive'] = '0';
        $_POST['jform']['access'] = '1';
        $_POST['jform']['published'] = '1';
        $_POST['jform']['section_id'] = '1';
        $_POST['jform']['type_id'] = '7';
        $_POST['jform']['id'] = '0';
        
        //instantiate the model
        $model = $controller->getModel();
        $model->getForm($emptyarray = array(), true);
        
        //load the table
        $table = $model->getTable();
        $table->check();
        $table->store();
        
        $task = $jinput->get('task', "edit", 'STR');
        $controller->execute($task);
        

        //Login the User This needs to change to Match an exisiting User

        $auth = & JAuthentication::getInstance();
        $credentials = array('username' => 'admin', 'password' => 'admin');
        $options = array();
        $response = $auth->authenticate($credentials, $options);

        //Get Token Name
        $token = JSession::getInstance()->getFormToken($forcenew = true);
        $jinput->post->set($token, '1');
        
        //Asign Post Data to Variable for testing
        $data = JFactory::getApplication()->input->post->get('jform', array(), 'array');

       //Execute the Edit function
        $task2 = $jinput->get('task', "save", 'STR');
        $controller->execute($task2);
        
        $response = "Edit Complete";
                
        $this->plugin->setResponse($response);
    }

}

// End Class

