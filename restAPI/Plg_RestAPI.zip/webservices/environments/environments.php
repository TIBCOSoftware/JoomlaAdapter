<?php

// This is the "API" / Application Interface for the APIX Project
//

//Includes

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controllerform');
jimport('joomla.user.authentication');
jimport('joomla.application.component.controller');
jimport('joomla.application.component.model');
jimport('joomla.access.access');
jimport('joomla.user.user');

require_once JPATH_ROOT . '\components\com_cobalt\controllers\form.php';
require_once JPATH_ROOT . '\components\com_cobalt\controllers\files.php';
require_once JPATH_ROOT . '\components\com_cobalt\controllers\records.php';
require_once JPATH_ROOT . '\libraries\joomla\session\session.php';
require_once JPATH_ROOT . '/components/com_cobalt/api.php';
require_once JPATH_ROOT . '\components\com_cobalt\models\form.php';
require_once JPATH_ROOT . '\components\com_cobalt\controllers\ajaxmore.php';
require_once JPATH_ROOT . '/libraries/legacy/model/legacy.php';
require_once JPATH_ROOT . '\components\com_cobalt\models\records.php';

class WebservicesApiResourceEnvironments extends ApiResource {


     //Function for making a new record in Cobalt
    public function post() {
        
    if (!$this->Authenticate())
		{
			echo("Authentication Failed");
			exit;
		}
		
        //****Saving the Record

        //INstance Cobalt Save controller and Token and Pass it Data
        $controller = new CobaltControllerForm();
        $jinput = JFactory::getApplication()->input;
        
        //Get Var from URLstring
        if (empty($jinput->get('title',"",'CMD'))) {
        $title = 'RandomTitle987654211';
        }
        else{
        $title  = $jinput->get('title',"",'CMD');
        } 
        
        if (empty($jinput->get('type',"",'CMD'))) {
        	$type = 'Testing';
        }
        else{
        	$type  = $jinput->get('type',"",'CMD');
        }
        
        if (empty($jinput->get('url',"",'CMD'))) {
        	$url = 'https://Basepath';
			
        }
        else{
        	$url  = $jinput->get('url',"",'CMD');
        }
        
        if (empty($jinput->get('description',"",'CMD'))) {
        	$description  = '<p>Description</p>';
        }
        else{
        	$description  = $jinput->get('description',"",'CMD');
        }
        
        
        if (empty($jinput->get('managedbygateway',"",'CMD'))) {
        $managedbygateway = true;
        }
        else{
        $managedbygateway  = $jinput->get('managedbygateway',"",'CMD');
        } 
        
        $_POST['jform']['title'] = $title;
        $_POST['jform']['ucatid'] = '0';
        $_POST['jform']['fields'][14][0]['url'] = $url;
         $_POST['jform']['fields'][14][0]['hits'] = '0';
        $_POST['jform']['fields'][143] = '';
        $_POST['jform']['fields'][141] = '';
        $_POST['jform']['fields'][140] = '';
        $_POST['jform']['fields'][13]  = $type;
        $_POST['jform']['fields'][139] = '';
        $_POST['jform']['fields'][138] = '';
        $_POST['jform']['fields'][137] = '';
        $_POST['jform']['fields'][136] = '';  
        $_POST['jform']['fields'][135] = '';
        $_POST['jform']['fields'][134] = '';
        $_POST['jform']['fields'][132] = '1'; /// ?? Gateway Management???
        $_POST['jform']['fields'][12]  = $description;
        $_POST['jform']['meta_descr'] = '';
        $_POST['jform']['meta_key'] = '';
        $_POST['jform']['meta_index'] = '';
        $_POST['jform']['alias'] = '';
        $_POST['jform']['ctime'] = date("Y-m-d H:i:s");
        $_POST['jform']['extime'] = '';
        $_POST['jform']['ftime'] = '';
        $_POST['jform']['langs'] = 'en-GB';
        $_POST['jform']['hidden'] = '0';
        $_POST['jform']['featured'] = '0';
        $_POST['jform']['user_id'] = '129';
        $_POST['jform']['archive'] = '0';
        $_POST['jform']['access'] = '6';
        $_POST['jform']['published'] = '1';
        $_POST['jform']['section_id'] = '3';
        $_POST['jform']['type_id'] = '4';
        $_POST['jform']['id'] = '0';
        
        if (!$managedbygateway)
        {
            $_POST['jform']['fields'][144] = '-1';
            $_POST['jform']['fields'][143] = 'Property File';
            $_POST['jform']['fields'][142] = '1';
            $_POST['jform']['fields'][141] = 'Operation Features';
            $_POST['jform']['fields'][140] = 'HeadersToForward';
            $_POST['jform']['fields'][139] = '3'; //Retry Timeout
            $_POST['jform']['fields'][138] = '2'; // Retry Interval
            $_POST['jform']['fields'][137] = '1'; // Retry COunt
            $_POST['jform']['fields'][136] = '20000';  //Timeout Required
            $_POST['jform']['fields'][135] = 'password';
            $_POST['jform']['fields'][134] = 'username';
            $_POST['jform']['fields'][132] = '-1';
            
        }
        
        //Get Token Name
        $token = JSession::getInstance()->getFormToken($forcenew = true);
        $jinput->post->set($token, '1');
        
        //Asign Post Data to Variable
        $data = JFactory::getApplication()->input->post->get('jform', array(), 'array');
        $jinput->set('jform',$data);
        
        //set save task
        $task = $jinput->get('task', "save", 'STR');
        
        //instantiate the model
        $model = $controller->getModel();
        $form = $model->getForm($emptyarray = array(), true);
          
       //Execute the task 
        $controller->execute($task);
        
       //Find the Created Environment and Display it.
        $api = new CobaltApi();
        $jinput = JFactory::getApplication()->input;
        
        $contentdata = $api->records(
        		$section_id = 3, 
				$view_what, 
				$orderby, 
				$type_ids = 4,
				$user_id,
				$category_id, 
				$limit = 1, 
				$template,
				$client,
				$client_id,
				$lang,
				$ids);
       
         $environmentID = $contentdata['ids'][0];
         $ids[] = $environmentID;
         
         $contentdata = $api->records(
         		$section_id = 3,
         		$view_what,
         		$orderby,
         		$type_ids = 4,
         		$user_id,
         		$category_id,
         		$limit = 1,
         		$template,
         		$client,
         		$client_id,
         		$lang,
         		$ids);
         
         $response = $this->getJsonFromObject($contentdata['list']);
         
         foreach ($response as $key => $value) {
         	unset($response[$key]['controls']);
         	unset($response[$key]['controls_notitle']);
         }
         
     
       $this->plugin->setResponse($response);
    }
    
        ///////////////////////////////
        ///**
	// * @param int    $section_id
	// * @param string $view_what
	// * @param string $order
	// * @param array  $type_ids
	// * @param null   $user_id   No user must be NULL, otherwise 0 would be Guest
	// * @param int    $cat_id
	// * @param int    $limit
	// * @param null   $tpl
	// * @param int    $client    name of the extension that use cobalt records
	// * @param string $client_id ID of the parent cobalt record
	// * @param bool   $lang      true or false. Selects only current language records or records on any language.
	// * @param array  $ids       Ids array of the records.
	// *
	// * @return array
	// */
        //Get
      public function get() {
      if (!$this->Authenticate())
		{
			echo("Authentication Failed");
			exit;
		}
		
        $api = new CobaltApi();
        $jinput = JFactory::getApplication()->input;
        
        if (empty($jinput->get('limit',"",'CMD'))) {
        $usersetlimit = 20;
        }
        else{
        $usersetlimit = $jinput->get('limit',"",'CMD');
        }
        
        
	    $environmentID = $jinput->get('id',"",'CMD');
        if ( !empty( $environmentID ) ){
            $ids[] = $environmentID;
        }
	    $data = $api->records(
		$section_id = 3, 
		$view_what, 
		$orderby, 
		$type_ids = 4,
		$user_id,
		$category_id, 
		$limit = $usersetlimit, 
		$template,
		$client,
		$client_id,
		$lang,
		$ids
            );
 
	    $response = $this->getJsonFromObject($data['list']);        

	    foreach ($response as $key => $value) {
	    	unset($response[$key]['controls']);
	    	unset($response[$key]['controls_notitle']);
	    }
	    
        $this->plugin->setResponse($response); // Sends Information to the Browser
     
    }// End Public Function get()
   
    //Function for Deleting a Record From Cobalt
    public function delete() {
        
    if (!$this->Authenticate())
		{
			echo("Authentication Failed");
			exit;
		}
		
        $controller = new CobaltControllerRecords();
        $jinput = JFactory::getApplication()->input;
        
        $idtodelete = $jinput->get('id',"",'CMD');
        
        $jinput->set('id',$idtodelete);
        
        if ($controller->delete())
        {
        $response = "Record #{$idtodelete} has been Deleted";
        }
        
        else 
        {
        $response = "Record #{$idtodelete} has not been Deleted For one or more Reasons:"
                . " Record Does not exsist," 
                . " Id is incorrect"
                . " Record could be open elsewhere for editing";    
        }
        
        $this->plugin->setResponse($response);
    }
    
    
    //Function for modifing a record in Cobalt
    public function put() {

    if (!$this->Authenticate())
		{
			echo("Authentication Failed");
			exit;
		}
		
        $controller = new CobaltControllerForm();
        $jinput = JFactory::getApplication()->input;

		$post_vars = file_get_contents("php://input");
		$data = array();
		parse_str($post_vars, $data);
        
		if (empty($data[title])) {
        }
        else{
        $_POST['jform']['title'] = $data[title];
        }
		
		if (empty($data[basepath])) {
        }
        else{
    	$_POST['jform']['fields'][14] = $data[basepath];
        }
		
		if (empty($data[type])) {
        }
        else{
    	 $_POST['jform']['fields'][13] = $data[type];
        }
		
		if (empty($data[description])) {
        }
        else{
    	 $_POST['jform']['fields'][12]  = $data[description];
        }
		
		if (empty($data[managedbygateway])) {
        }
        else{
    	 $_POST['jform']['fields'][132]  = $data[managedbygateway];
        }
		
        //Fake Post Data
		$_POST['jform']['id'] = $data[id];
        $_POST['jform']['ucatid'] = '0';
        $_POST['jform']['fields'][5] = 'wahaha';
        $_POST['jform']['fields'][145] = '1';
        $_POST['jform']['fields'][44] = '';
        $_POST['jform']['meta_descr'] = '';
        $_POST['jform']['meta_key'] = '';
        $_POST['jform']['meta_index'] = '';
        $_POST['jform']['alias'] = '';
        $_POST['jform']['ctime'] = '2014-11-17 21:47:11';
        $_POST['jform']['extime'] = '';
        $_POST['jform']['ftime'] = '';
        $_POST['jform']['langs'] = 'en-GB';
        $_POST['jform']['hidden'] = '0';
        $_POST['jform']['featured'] = '0';
        $_POST['jform']['user_id'] = '129';
        $_POST['jform']['archive'] = '0';
        $_POST['jform']['access'] = '6';
        $_POST['jform']['published'] = '1';
        $_POST['jform']['section_id'] = '2';
        $_POST['jform']['type_id'] = '2';
        


        $returnId = $this->update( $_POST );
        $obj = $this->getDataById($returnId);
        $this->getJsonFromObject($contentdata['list']);
       
	    $api = new CobaltApi();
        $jinput = JFactory::getApplication()->input;
        
        
	    $environmentID = $data[id];
        if ( !empty( $environmentID ) ){
            $ids[] = $environmentID;
        }
	    $data = $api->records(
		$section_id = 3, 
		$view_what, 
		$orderby, 
		$type_ids = 4,
		$user_id,
		$category_id, 
		$limit = $usersetlimit, 
		$template,
		$client,
		$client_id,
		$lang,
		$ids
            );
            
        
	    $response = $this->getJsonFromObject($data['list']);
	    foreach ($response as $key => $value) {
	    	unset($response[$key]['controls']);
	    	unset($response[$key]['controls_notitle']);
	    }
        $this->plugin->setResponse($response); // Sends Information to the Browser
    }

    private function getJsonFromObject($data){
        $resultArr = array();
        foreach ( $data as $obj ) {
            $array = get_object_vars($obj);
            $newArr = array();
            foreach ( $array as $key => $val ){
                if ( $key === 'params' ) {
                    $tmp = get_object_vars($val);
                    foreach( $tmp as $pk => $pv ){
                        $newArr[$key][$pk] = (array)$pv;
                    }

                }elseif( $key === 'ctime' || $key === 'mtime' ){
                    $tmp = get_object_vars($val);
                    foreach( $tmp as $tk => $tv ){
                        $newArr[$key][$tk] = (array)$tv;
                    }
                }elseif( $key !== 'fields_by_id' && $key !== 'fields_by_groups' && $key !== 'fields_by_key' ){
                    $newArr[$key] = $val;
                }
            }
            $resultArr[]=$newArr;
        }
        return $resultArr;
    }

    private function update(){
        $form = $_POST['jform'];
        if ( !$form ){
            return false;
        }
        $id = $form['id'];
        unset($form['id']);
        unset($form['section_id']);
        unset($form['type_id']);
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select( $db->quoteName(array('fields')) )
            ->from($db->quoteName('#__js_res_record'))
            ->where($db->quoteName('id').'='.$id)
            ->setLimit(1);
        $db->setQuery($query);
        $result = $db->loadResult();
        $fieldsArr = json_decode($result, true);
        foreach ( $form['fields'] as $col=>$val ){
            if ( $col === 14 )
                $val = array( array("url"=>$val) );
            else if ( $col === 13 )
                $val = array($val);
            $fieldsArr[$col] = $val;
        }
        $fieldsJson = json_encode($fieldsArr);
        $form['fields'] = $fieldsJson;
        foreach( $form as $col => $val ){
            $fields[] = $db->quoteName($col) . ' = ' . $db->quote($val);
        }
        $querys = $db->getQuery(true);
        $querys->update($db->quoteName('#__js_res_record'))->set($fields)->where( $db->quoteName('id') . ' = '.$id );

        $db->setQuery($querys);
        $result = $db->execute();
        if ( $result ) {
            $res = $this->uploadValue($id, $form['fields']);
        } else {
            return fasle;
        }
        return $id;
    }

    private function uploadValue($record_id, $fieldsJson){
        $fields = json_decode($fieldsJson);
        $db = JFactory::getDbo();
        foreach( $fields as $key => $val ) {
            if ( !empty( $val ) ) {
                if(is_array($val))
                    $val = $val[0];
                $db->setQuery('SELECT `id` FROM `#__js_res_record_values` WHERE `record_id` = '.$record_id.' AND `field_id` ='.$key);
                $id = $db->loadResult();
                if ( $id ) {
                    $query = $db->getQuery(true);
                    $query->update($db->quoteName('#__js_res_record_values'))->set(array($db->quoteName('field_value') . ' = ' . $db->quote($val)))->where($db->quoteName('record_id') . ' = ' . $id);
                    $db->setQuery($query);
                    $db->execute();
                } else {
                    $db->setQuery('SELECT `key`, `label`, `field_type` FROM `#__js_res_fields` WHERE `id`='.$key);
                    $field = $db->loadObject();
                    $query = $db->getQuery(true);
                    $columns = array('field_id', 'field_key', 'field_type', 'field_label', 'field_value', 'record_id', 'user_id', 'type_id', 'section_id','category_id','ip','ctime');
                    $values = array($key, $db->quote($field->key), $db->quote($field->field_type), $db->quote($val), $db->quote($field->label), $record_id, $_POST['jform']['user_id'], $_POST['jform']['type_id'], $_POST['jform']['section_id'], 0, $db->quote('::1'),$db->quote(date('Y-m-d H:i:s', time())));
                    $query->insert($db->quoteName('#__js_res_record_values'))->columns($db->quoteName($columns))->values(implode(',', $values));
                    $db->setQuery($query);
                    $db->execute();
                }
            }
        }
        return true;
    }

    private function getDataById($id){
        $api = new CobaltApi();
        $jinput = JFactory::getApplication()->input;

        if (empty($jinput->get('limit',"",'CMD'))) {
            $usersetlimit = 20;
        }
        else{
            $usersetlimit = $jinput->get('limit',"",'CMD');
        }

        $data = $api->records(
            $section_id = 3,
            $view_what,
            $orderby,
            $type_ids = 4,
            $user_id,
            $category_id,
            $limit = $usersetlimit,
            $template,
            $client,
            $client_id,
            $lang,
            $id
        );
        return $data['list'];
    }
	private function Authenticate()
{
	    /////////////////////////////
      	////Login Event CURL CALL
      	//
      	
      	$check1 = $_SERVER['PHP_AUTH_USER'];
    	$check2 = $_SERVER['PHP_AUTH_PW'];
    	
    	$check1;
    	$check2;
    	
    	$credentials = array(
    			'username' => $check1,
    			'password' => $check2,
    	);
    	
    	$options = array();
    	$auth = & JAuthentication::getInstance();
    	$authorization = $auth->authenticate($credentials, $options);
    	
    	//set response
    	
    	if ($authorization->status != JAuthentication::STATUS_SUCCESS)
    	{
    		header('HTTP/1.1 400 Bad Request', true, 400);
    		$response = "{$username} cannot be logged on The password or username pair is not correct.";
    	}
    	
    	else
    	{
    		$date =& JFactory::getDate();
    		
    		$mainframe =& JFactory::getApplication('site');
    		$mainframe->initialise();
    		
    		$mainframe->login($credentials);
    		$token = bin2hex(openssl_random_pseudo_bytes(16));
    		$user = JFactory::getUser();
    		$idholder = $user->id;
    		return $idholder;
			}
	}

}

// End Class

