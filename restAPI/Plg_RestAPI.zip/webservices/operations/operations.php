<?php

// This is the "API" / Application Interface for the APIX Project
//

//Includes

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controllerform');
jimport('joomla.user.authentication');
jimport('joomla.application.component.controller');
jimport('joomla.application.component.model');
jimport('joomla.access.access');
jimport('joomla.user.user');

require_once JPATH_ROOT . '\components\com_cobalt\controllers\form.php';
require_once JPATH_ROOT . '\components\com_cobalt\controllers\files.php';
require_once JPATH_ROOT . '\components\com_cobalt\controllers\records.php';
require_once JPATH_ROOT . '\libraries\joomla\session\session.php';
require_once JPATH_ROOT . '/components/com_cobalt/api.php';
require_once JPATH_ROOT . '\components\com_cobalt\models\form.php';
require_once JPATH_ROOT . '\components\com_cobalt\controllers\ajaxmore.php';

class WebservicesApiResourceOperations extends ApiResource {


     //Function for making a new record in Cobalt
    public function post() {

    	if (!$this->Authenticate())
		{
			echo("Authentication Failed");
			exit;
		}
		
        $controller = new CobaltControllerForm();
        $jinput = JFactory::getApplication()->input;
        
        $nickname = $jinput->get('nickname',"",'CMD');
        $method = $jinput->get('method',"",'CMD');
        $summary = $jinput->get('summary',"",'CMD');
        $path = $jinput->get('path',"",'CMD');
        $api_id = $jinput->get('api_id',"",'CMD');
        
        $path = $this->decode($path, "KEY");
        //$summary = $this->decode($summary, "KEY");
             
        
            $_POST['jform']['fields'][28] = $path;
            $_POST['jform']['title']      = $nickname;
            $_POST['jform']['fields'][29] = $method;
            $_POST['jform']['fields'][27] = $summary;
            //Create an Operation on Created File
            $_POST['jform']['ucatid'] = '0';
            $_POST['jform']['fields'][149] = '';
            //$_POST['jform']['fields'][27] = '';
            //$_POST['jform']['fields'][28] = 'URI PATH';
            //$_POST['jform']['fields'][29] = '';
            $_POST['jform']['fields'][30] = $api_id;
            $_POST['jform']['fields'][108] = 'b79f4d70-6c92-3894-3c7c-17c5bb277f5c';
            $_POST['jform']['meta_descr'] = '';
            $_POST['jform']['meta_key'] = '';
            $_POST['jform']['meta_index'] = '';
            $_POST['jform']['alias'] = '';
            $_POST['jform']['ctime'] = date("Y-m-d H:i:s");
            $_POST['jform']['extime'] = '';
            $_POST['jform']['ftime'] = '';
            $_POST['jform']['langs'] = 'en-GB';
            $_POST['jform']['hidden'] = '0';
            $_POST['jform']['featured'] = '0';
            $_POST['jform']['user_id'] = '129';
            $_POST['jform']['archive'] = '0';
            $_POST['jform']['access'] = '6';
            $_POST['jform']['published'] = '1';
            $_POST['jform']['section_id'] = '2';
            $_POST['jform']['type_id'] = '6';
            $_POST['jform']['id'] = 0;  

            $data = $_POST['jform'];
            
            $jinput->post->set('jform',$data);            
            
            $task = $jinput->get('task', "save", 'STR');
            $token = JSession::getInstance()->getFormToken($forcenew = true);
            $jinput->post->set($token, '1');

            $controller->execute($task);

		$api = new CobaltApi();
        $jinput = JFactory::getApplication()->input;
        
        if (empty($jinput->get('limit',"",'CMD'))) {
        $usersetlimit = 5;
        }
        else{
        $usersetlimit = $jinput->get('limit',"",'CMD');
        }
        
        $data = $api->records(
		$section_id = 2, 
		$view_what, 
		$orderby, 
		$type_ids = 6,
		$user_id,
		$category_id, 
		$limit = $usersetlimit, 
		$template,
		$client,
		$client_id,
		$lang,
		$ids
            );
			
			//$returnId = $this->update();
			$this->plugin->setResponse($path);   
            //$this->plugin->setResponse($data['list'][0]);
    }
    
     //Get
    public function get() {
        
    if (!$this->Authenticate())
		{
			echo("Authentication Failed");
			exit;
		}
		
        $api = new CobaltApi();
        $jinput = JFactory::getApplication()->input;
        
        if (empty($jinput->get('limit',"",'CMD'))) {
        $usersetlimit = 20;
        }
        else{
        $usersetlimit = $jinput->get('limit',"",'CMD');
        }
        
        $environmentID = $jinput->get('id',"",'CMD');
        if ( !empty( $environmentID ) ){
            $ids[] = $environmentID;
        }
        $contentdata = $api->records(
		$section_id = 2, 
		$view_what, 
		$orderby, 
		$type_ids = 6,
		$user_id,
		$category_id, 
		$limit = $usersetlimit, 
		$template,
		$client,
		$client_id,
		$lang,
		$ids
            );

        //printf('Found %d records total', $data['total']);
        
        //foreach($data['list'] AS $item) {
        //printf('<li><a href="%s">%s</a></li>', $item->url, $item->title); 
        //}
        
        //$response = json_encode($data['list']);
        $response = $this->getJsonFromObject($contentdata['list']);
        foreach ($response as $key => $value) {
        	unset($response[$key]['controls']);
        	unset($response[$key]['controls_notitle']);
        }                         
           
        $this->plugin->setResponse($response); // Sends Information to the Browser  
     
    }// End Public Function get()
   
    //Function for Deleting a Record From Cobalt
    public function delete() {
    if (!$this->Authenticate())
		{
			echo("Authentication Failed");
			exit;
		}
		
        $controller = new CobaltControllerRecords();
        $jinput = JFactory::getApplication()->input;
        
        $idtodelete = $jinput->get('id',"",'CMD');
        
        $jinput->set('id',$idtodelete);
        
        //This isn't working correctly It's Deleteing but the error reporting is incorrect.
        if ($controller->delete())
        {
        $response = "Record #{$idtodelete} has been Deleted";
        }
        
        else 
        {
        $response = "Record #{$idtodelete} has not been Deleted For one or more Reasons:"
                . " Record Does not exsist," 
                . " Id is incorrect"
                . " Record could be open elsewhere for editing";    
        }
        
        $this->plugin->setResponse($response);
    }
    
    
    //Function for modifing a record in Cobalt
    public function put() {
    if (!$this->Authenticate())
		{
			echo("Authentication Failed");
			exit;
		}
        $controller = new CobaltControllerForm();
        $jinput = JFactory::getApplication()->input;

		$post_vars = file_get_contents("php://input");
		$data = array();
		parse_str($post_vars, $data);
        
		if (empty($data[id])) {
        }
        else{
        $_POST['jform']['id'] = $data[id];
        }
		
		if (empty($data[nickname])) {
        }
        else{
        $_POST['jform']['title'] = $data[nickname];
        }
		
		if (empty($data[path])) {
        }
        else{
    	$_POST['jform']['fields'][28] = $data[path];
        }
		
		if (empty($data[api_id])) {
        }
        else{
    	 $_POST['jform']['fields'][30] = $data[api_id];
        }
		
		if (empty($data[summary])) {
        }
        else{
    	 $_POST['jform']['fields'][27]  = $data[summary];
        }
		
		if (empty($data[method])) {
        }
        else{
    	 $_POST['jform']['fields'][29]  = $data[method];
        }
		
        //Fake Post Data
			//$_POST['jform']['id'] = $data[id];

            //Create an Operation on Created File
            $_POST['jform']['ucatid'] = '0';
            $_POST['jform']['fields'][149] = '';
            //$_POST['jform']['fields'][27] = '';
            //$_POST['jform']['fields'][28] = 'URI PATH';
            //$_POST['jform']['fields'][29] = '';
            //$_POST['jform']['fields'][30] = $api_id;
            $_POST['jform']['fields'][108] = 'b79f4d70-6c92-3894-3c7c-17c5bb277f5c';
            $_POST['jform']['meta_descr'] = '';
            $_POST['jform']['meta_key'] = '';
            $_POST['jform']['meta_index'] = '';
            $_POST['jform']['alias'] = '';
            $_POST['jform']['ctime'] = date("Y-m-d H:i:s");
            $_POST['jform']['extime'] = '';
            $_POST['jform']['ftime'] = '';
            $_POST['jform']['langs'] = 'en-GB';
            $_POST['jform']['hidden'] = '0';
            $_POST['jform']['featured'] = '0';
            $_POST['jform']['user_id'] = '129';
            $_POST['jform']['archive'] = '0';
            $_POST['jform']['access'] = '6';
            $_POST['jform']['published'] = '1';
            $_POST['jform']['section_id'] = '2';
            $_POST['jform']['type_id'] = '6';       


        $returnId = $this->update();
        $obj = $this->getDataById($returnId);
        
	    $response = $this->getJsonFromObject($obj);
	    foreach ($response as $key => $value) {
	    	unset($response[$key]['controls']);
	    	unset($response[$key]['controls_notitle']);
	    }
        $this->plugin->setResponse($response[0]); // Sends Information to the Browser
    }

    public function decode($string,$key) {
    $key = sha1($key);
    $strLen = strlen($string);
    $keyLen = strlen($key);
    for ($i = 0; $i < $strLen; $i+=2) {
        $ordStr = hexdec(base_convert(strrev(substr($string,$i,2)),36,16));
        if ($j == $keyLen) { $j = 0; }
        $ordKey = ord(substr($key,$j,1));
        $j++;
        $hash .= chr($ordStr - $ordKey);
    }
    return $hash;
}
 private function getJsonFromObject($data){
        $resultArr = array();
        foreach ( $data as $obj ) {
            $array = get_object_vars($obj);
            $newArr = array();
            foreach ( $array as $key => $val ){
                if ( $key === 'params' ) {
                    $tmp = get_object_vars($val);
                    foreach( $tmp as $pk => $pv ){
                        $newArr[$key][$pk] = (array)$pv;
                    }

                }elseif( $key === 'ctime' || $key === 'mtime' ){
                    $tmp = get_object_vars($val);
                    foreach( $tmp as $tk => $tv ){
                        $newArr[$key][$tk] = (array)$tv;
                    }
                }elseif( $key !== 'fields_by_id' && $key !== 'fields_by_groups' && $key !== 'fields_by_key' ){
                    $newArr[$key] = $val;
                }
            }
            $resultArr[]=$newArr;
        }
        return $resultArr;
    }

    private function update(){
        $form = $_POST['jform'];
        if ( !$form ){
            return false;
        }
        $id = $form['id'];
        unset($form['id']);
        unset($form['section_id']);
        unset($form['type_id']);
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select( $db->quoteName(array('fields')) )
            ->from($db->quoteName('#__js_res_record'))
            ->where($db->quoteName('id').'='.$id)
            ->setLimit(1);
        $db->setQuery($query);
        $result = $db->loadResult();
        $fieldsArr = json_decode($result, true);
        foreach ( $form['fields'] as $col=>$val ){
            if ( $col === 14 )
                $val = array( array("url"=>$val) );
            else if ( $col === 13 )
                $val = array($val);
            $fieldsArr[$col] = $val;
        }
        $fieldsJson = json_encode($fieldsArr);
        $form['fields'] = $fieldsJson;
        foreach( $form as $col => $val ){
            $fields[] = $db->quoteName($col) . ' = ' . $db->quote($val);
        }
        $querys = $db->getQuery(true);
        $querys->update($db->quoteName('#__js_res_record'))->set($fields)->where( $db->quoteName('id') . ' = '.$id );

        $db->setQuery($querys);
        $result = $db->execute();
        if ( $result ) {
            $res = $this->uploadValue($id, $form['fields']);
        } else {
            return fasle;
        }
        return $id;
    }

    private function uploadValue($record_id, $fieldsJson){
        $fields = json_decode($fieldsJson);
        $db = JFactory::getDbo();
        foreach( $fields as $key => $val ) {
            if ( !empty( $val ) ) {
                if(is_array($val))
                    $val = $val[0];
                $db->setQuery('SELECT `id` FROM `#__js_res_record_values` WHERE `record_id` = '.$record_id.' AND `field_id` ='.$key);
                $id = $db->loadResult();
                if ( $id ) {
                    $query = $db->getQuery(true);
                    $query->update($db->quoteName('#__js_res_record_values'))->set(array($db->quoteName('field_value') . ' = ' . $db->quote($val)))->where($db->quoteName('record_id') . ' = ' . $id);
                    $db->setQuery($query);
                    $db->execute();
                } else {
                    $db->setQuery('SELECT `key`, `label`, `field_type` FROM `#__js_res_fields` WHERE `id`='.$key);
                    $field = $db->loadObject();
                    $query = $db->getQuery(true);
                    $columns = array('field_id', 'field_key', 'field_type', 'field_label', 'field_value', 'record_id', 'user_id', 'type_id', 'section_id','category_id','ip','ctime');
                    $values = array($key, $db->quote($field->key), $db->quote($field->field_type), $db->quote($val), $db->quote($field->label), $record_id, $_POST['jform']['user_id'], $_POST['jform']['type_id'], $_POST['jform']['section_id'], 0, $db->quote('::1'),$db->quote(date('Y-m-d H:i:s', time())));
                    $query->insert($db->quoteName('#__js_res_record_values'))->columns($db->quoteName($columns))->values(implode(',', $values));
                    $db->setQuery($query);
                    $db->execute();
                }
            }
        }
        return true;
    }

    private function getDataById($id){
        $api = new CobaltApi();
        $jinput = JFactory::getApplication()->input;

        if (empty($jinput->get('limit',"",'CMD'))) {
            $usersetlimit = 20;
        }
        else{
            $usersetlimit = $jinput->get('limit',"",'CMD');
        }

        $data = $api->records(
            $section_id = 2,
            $view_what,
            $orderby,
            $type_ids = 6,
            $user_id,
            $category_id,
            $limit = $usersetlimit,
            $template,
            $client,
            $client_id,
            $lang,
            $id
        );
        return $data['list'];
    }

private function Authenticate()
	{
	    /////////////////////////////
      	////Login Event CURL CALL
      	//
      	
      	$check1 = $_SERVER['PHP_AUTH_USER'];
    	$check2 = $_SERVER['PHP_AUTH_PW'];
    	
    	$check1;
    	$check2;
    	
    	$credentials = array(
    			'username' => $check1,
    			'password' => $check2,
    	);
    	
    	$options = array();
    	$auth = & JAuthentication::getInstance();
    	$authorization = $auth->authenticate($credentials, $options);
    	
    	//set response
    	
    	if ($authorization->status != JAuthentication::STATUS_SUCCESS)
    	{
    		header('HTTP/1.1 400 Bad Request', true, 400);
    		$response = "{$username} cannot be logged on The password or username pair is not correct.";
    	}
    	
    	else
    	{
    		$date =& JFactory::getDate();
    		
    		$mainframe =& JFactory::getApplication('site');
    		$mainframe->initialise();
    		
    		$mainframe->login($credentials);
    		$token = bin2hex(openssl_random_pseudo_bytes(16));
    		$user = JFactory::getUser();
    		$idholder = $user->id;
    		return $idholder;
			}
	}
}

// End Class

