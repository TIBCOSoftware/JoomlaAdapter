<?php

// This is the "API" / Application Interface for the APIX Project
//

//Includes

defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controllerform');
jimport('joomla.user.authentication');
jimport('joomla.application.component.controller');
jimport('joomla.application.component.model');
jimport('joomla.access.access');
jimport('joomla.user.user');

require_once JPATH_ROOT . '/components/com_cobalt/controllers/form.php';
require_once JPATH_ROOT . '/components/com_cobalt/controllers/files.php';
require_once JPATH_ROOT . '/components/com_cobalt/controllers/records.php';
require_once JPATH_ROOT . '/libraries/joomla/session/session.php';
require_once JPATH_ROOT . '/components/com_cobalt/api.php';
require_once JPATH_ROOT . '/components/com_cobalt/models/form.php';
require_once JPATH_ROOT . '/components/com_cobalt/controllers/ajaxmore.php';
require_once JPATH_ROOT . '/libraries/legacy/model/legacy.php';
require_once JPATH_ROOT . '/components/com_cobalt/models/records.php';
require_once JPATH_ROOT . '/includes/defines.php';
require_once JPATH_ROOT . '/includes/framework.php';
require_once JPATH_ROOT . '/includes/api.php';

jimport('joomla.user.authentication');
jimport( 'joomla.session.session' );

class WebservicesApiResourceApis extends ApiResource {


     //Function for making a new record in Cobalt
    public function post() {

    	if (!$userid = $this->Authenticate())
    	 {
    	 echo("Authentication Failed");
    	 exit;
    	 }

    	$user = JFactory::getUser($userid);
    	
    		if( ( in_array(7, $user->getAuthorisedGroups() ) || in_array( 8, $user->getAuthorisedGroups() ) || in_array( 11, $user->getAuthorisedGroups() ))  )
    		{
    			$jinput = JFactory::getApplication()->input;
    		
    			//*****Check for Uploaded Json File
    		
    			if(empty($_FILES)) {
    				// NO FILE
    				//$jsonfilepath = null;
    			}
    		
    			else{
    				//Instance Cobalt File Controller and Upload File
    				$uploadcontroller = new CobaltControllerFiles();
    				$uploadtask = $jinput->get('task', "upload", 'STR');
    				$uploadcontroller->execute($uploadtask);
    		
    				//Get the temp name of the uploaded file for record creation.
    				$jsonfilename = $uploadcontroller->tempname;
    				//$otherjsonname = $uploadcontroller->tempname2;
    		
    				//Get the filename for operation creation.
    				$jsonfilepath = JPATH_ROOT . DIRECTORY_SEPARATOR . 'uploads'. DIRECTORY_SEPARATOR . 'json' . DIRECTORY_SEPARATOR . date("Y-m") . DIRECTORY_SEPARATOR . $jsonfilename;
    		
    				//Get Contents of said file and put in a string.
    				$jsonfilecontents = file_get_contents( $jsonfilepath );
    		
    				//Decode the json file
    				$jsondata = json_decode($jsonfilecontents, true);
    			}

    			//****Saving the Record
    		
    			//INstance Cobalt Save controller and Token and Pass it Data
    			$controller = new CobaltControllerForm();
    			$jinput = JFactory::getApplication()->input;
    		
		if (empty($jinput->get('title',"",'CMD'))) {
    			}
    			else{
    				$title  = $jinput->get('title',"",'CMD');
				$_POST['jform']['title'] = $title;
    			}

			if (empty($jinput->get('environment',"",'CMD'))) {
    			}
    			else{
    				$environment  = $jinput->get('environment',"",'CMD');
				$_POST['jform']['fields'][26][0] = $environment;
    			}
    			
    			if (empty($jinput->get('targetenvironment',"",'CMD'))) {
    			}
    			else{
    				$targetenvironment  = $jinput->get('targetenvironment',"",'CMD');
				$_POST['jform']['fields'][147][0] = $targetenvironment;
    			}
    			
    			if (empty($jinput->get('description',"",'CMD'))) {
    			}
    			else{
    				$description  = $jinput->get('description',"",'CMD');
				$_POST['jform']['fields'][5] = $description;
    			}
    			
    			if (empty($jinput->get('type',"",'CMD'))) {
    			}
    			else{
    				$type  = $jinput->get('type',"",'CMD');
				$_POST['jform']['fields'][75] = $type;
    			}
    			
			if (empty($jinput->get('proxy',"",'CMD'))) {
    			}
    			else{
    				$proxy  = $jinput->get('proxy',"",'CMD');
				
				if ( $proxy == "true"){
					$_POST['jform']['fields'][145] = true;
				}
				else{
					$_POST['jform']['fields'][145] = false;
				}
    			}

    			
    			$_POST['jform']['ucatid'] = '0';
    
    			
    			
    			if(!empty($_FILES)) {
			
    				$_POST['jform']['fields'][23][0] = $jsonfilename;
    			} 

    			
    			
    			//$_POST['jform']['fields'][23][0] = $otherjsonname;
    			//$_POST['jform']['fields'][26][0] = '442';
    			//$_POST['jform']['fields'][147][0] = '223';
    			//$_POST['jform']['fields'][26][0] = $environment; //442
    			//$_POST['jform']['fields'][147][0] = $targetenvironment; //223
    			//$_POST['jform']['fields'][24][0] = '1416214800_d6473a7630285b675ef9fe9710871046.docx'; //Documentation
    			$_POST['jform']['fields'][44] = '';
    			$_POST['jform']['meta_descr'] = '';
    			$_POST['jform']['meta_key'] = '';
    			$_POST['jform']['meta_index'] = '';
    			$_POST['jform']['alias'] = '';
    			$_POST['jform']['ctime'] = date("Y-m-d H:i:s");
    			$_POST['jform']['extime'] = '';
    			$_POST['jform']['ftime'] = '';
    			$_POST['jform']['langs'] = 'en-GB';
    			$_POST['jform']['hidden'] = '0';
    			$_POST['jform']['featured'] = '0';
    		        $_POST['jform']['user_id'] = $userid;
    			$_POST['jform']['archive'] = '0';
    			$_POST['jform']['access'] = '6';
    			$_POST['jform']['published'] = '1';
    			$_POST['jform']['section_id'] = '2';
    			$_POST['jform']['type_id'] = '2';

			
    			//Get Token Name
    			$token = JSession::getInstance()->getFormToken($forcenew = true);
    			$jinput->post->set($token, '1');
    		
    			//set save task
    			$task = $jinput->get('task', "save", 'STR');

    			//instantiate the model
    			$model = $controller->getModel();
    			$form = $model->getForm();
			//$form = $model->getForm($emptyarray = array(), true);
	
    			//Execute the task
    			$controller->execute($task);
			
			
			//$this->update( $_POST );
			 
    			//****OPERATION TO GET ID
    			// Gets most recently created ID
    			if(!empty($_FILES))
    			{
    				$api = new CobaltApi();
    				$jinput = JFactory::getApplication()->input;
    		
    				$contentdata = $api->records(
    						$section_id = 2,
    						$view_what,
    						$orderby,
    						$type_ids = 2,
    						$user_id,
    						$category_id,
    						$limit = 1,
    						$template,
    						$client,
    						$client_id,
    						$lang,
    						$ids
    				);
    		
    				$api_id = $contentdata['ids'][0];
    		
    				/////////////////////////////
    				////OPERATION CURL CALL
    				//
    				//    'nickname' => 0,
    				//    'method' => 0,
    				//    'summary' => 0,
    				//    'path' => 0,
    				/////////////////////////////
    		
    				$url =  JURI::root() . "index.php?option=com_api&app=webservices&resource=operations";
    				$count = count($jsondata['apis']);
    				$data = array();
    		
    				// For each API in the Json File
    				for ($x = 0; $x < $count; $x++) {
    		
    					$data['path'] = $this->encode($jsondata['apis'][$x]['path'], "KEY");
    					$count2 = count($jsondata['apis'][$x]['operations']);
    		
    					//For each operation
    					for ($y = 0; $y < $count2; $y++){
    		
    						$data['nickname'] = $jsondata['apis'][$x]['operations'][$y]['nickname'];
    						$data['method']   = $jsondata['apis'][$x]['operations'][$y]['method'];
    						$data['summary']  = $this->encode($jsondata['apis'][$x]['operations'][$y]['summary'], "KEY");
    						$data['api_id'] = $api_id;
    		
    						$curl = curl_init();
    		
    						curl_setopt($curl, CURLOPT_URL, $url);
    						curl_setopt($curl, CURLOPT_POST, 1);
    						curl_setopt($curl, CURLOPT_HTTPHEADER, 'Content-type: text/plain');
    						curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    		
    						$resp = curl_exec($curl);
    						curl_close($curl);
    					}
    				}
    			}
    		
    		
    		
    			/////////////////////////////
    			////Portal Event CURL CALL
    			//
    			//    'eventType' => 0,
    			//    'id' => 0,
    			//    'objectType' => 0,
    			//    'userId' => 0,
    			/////////////////////////////
    		
    			$url2 = JURI::root() . 'portalEvent';
    		
    			$data = array(
    					'eventType' => "Create",
    					'id' => $api_id,  //Id of the API
    					'objectType' => "API",
    					'userId' => $userid,
    			);
    		
    			$curl = curl_init();
    		
    			curl_setopt($curl, CURLOPT_URL, $url2);
    			curl_setopt($curl, CURLOPT_POST, 1);
    			curl_setopt($curl, CURLOPT_HTTPHEADER, 'Content-type: text/plain');
    			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    		
    			$resp = curl_exec($curl);
    			curl_close($curl);
    			 
    			$response = $this->getDataById($api_id);
    			//$response = "Hey you made an API with the name {$title} and userid of {$userid}";
    		
    		}
    		 
    		else
    		{
    			$response = "You do not have permission to create an API ";
    		}
    	
    		$this->plugin->setResponse($response);
    	
    }
    
    
    
    
    
    
    
        ///////////////////////////////
        ///**
	// * @param int    $section_id
	// * @param string $view_what
	// * @param string $order
	// * @param array  $type_ids
	// * @param null   $user_id   No user must be NULL, otherwise 0 would be Guest
	// * @param int    $cat_id
	// * @param int    $limit
	// * @param null   $tpl
	// * @param int    $client    name of the extension that use cobalt records
	// * @param string $client_id ID of the parent cobalt record
	// * @param bool   $lang      true or false. Selects only current language records or records on any language.
	// * @param array  $ids       Ids array of the records.
	// *
	// * @return array
	// */
        //Get
      public function get() {
        
      	//Check the Token to see if valid.
      	
      	if (!$userid = $this->Authenticate())
      	{
      		echo("Authentication Failed");
      		exit;
      	}
      	
      		$jinput = JFactory::getApplication()->input;
      		$user = JFactory::getUser($userid);
      		//ehco ($userid);

		        $api = new CobaltApi();
		        $jinput = JFactory::getApplication()->input;
		        
		        
		        if (empty($jinput->get('limit',"",'CMD'))) {
		        $usersetlimit = 5;
		        }
		        else{
		        $usersetlimit = $jinput->get('limit',"",'CMD');
		        }
		        
		        
		        if (empty($jinput->get('id',"",'CMD'))) {
		        }
		        else
		        {
		        	$id = $jinput->get('id',"",'CMD');
		        }
		        
		        $data = $api->records(
				$section_id = 2, 
				$view_what, 
				$orderby, 
				$type_ids = 2,
				$user_id,
				$category_id, 
				$limit = $usersetlimit, 
				//$limit,
				$template,
				$client,
				$client_id,
				$lang,
				$ids
		            );
		
		        $count = $data['total'];
		         
		        ///////////////////////////
		        // Permissions
		         
		        if( ( in_array(7, $user->getAuthorisedGroups() ) || in_array( 8, $user->getAuthorisedGroups() ) || in_array( 11, $user->getAuthorisedGroups() ))  )
		        	{
		                if ( isset ($id))
		        			{
						        if (  in_array ( $id , $data['ids']) == true )
						        	{
						        	
									$environmentID = $jinput->get('id',"",'CMD');
									if ( !empty( $environmentID ) ){
									    $ids[] = $environmentID;
									}
									    $data = $api->records(
										$section_id = 2, 
										$view_what, 
										$orderby, 
										$type_ids = 2,
										$user_id,
										$category_id, 
										$limit = $usersetlimit, 
										$template,
										$client,
										$client_id,
										$lang,
										$ids
									    );
								 
									    $response = $data['list'];  
						       		 }
		        
		        
		        			}
		        
						        else{

						        	$response = $data['list'];
						        }
		             }
		            
        
        $this->plugin->setResponse($response); // Sends Information to the Browser
      	
    }// End Public Function get()
   
    //Function for Deleting a Record From Cobalt
    public function delete() {
    if (!$this->Authenticate())
		{
			echo("Authentication Failed");
			exit;
		}
        $controller = new CobaltControllerRecords();
        $jinput = JFactory::getApplication()->input;
        
        $idtodelete = $jinput->get('id',"",'CMD');
        
        $jinput->set('id',$idtodelete);
        
        if ($controller->delete())
        {
        $response = "Record #{$idtodelete} has been Deleted";
        }
        
        else 
        {
        $response = "Record #{$idtodelete} has not been Deleted For one or more Reasons:"
                . " Record Does not exsist," 
                . " Id is incorrect"
                . " Record could be open elsewhere for editing";    
        }
        
          /////////////////////////////
        ////Portal Event CURL CALL
        //
        //    'eventType' => 0,
        //    'id' => 0,
        //    'objectType' => 0,
        //    'userId' => 0,
        /////////////////////////////
        
        $url = 'http://localhost/Joomla3.4TibcoAdap2.1/portalEvent';
        
        $data = array(
        'eventType' => "Delete",
        'id' => $idtodelete,
        'objectType' => "API",
        );
        
        $curl = curl_init();
        
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_HTTPHEADER, 'Content-type: text/plain');
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        
        $resp = curl_exec($curl);
        curl_close($curl);
        
        $this->plugin->setResponse($response);
    }
    
    
    //Function for modifing a record in Cobalt
    public function put() {

    if (!$this->Authenticate())
		{
			echo("Authentication Failed");
			exit;
		}
    	//Checking for Json File Upload
    	//////////////

    	if(empty($_FILES)) {
    		// NO FILE
    		//$jsonfilepath = null;
    	}

    	else{
    		//Instance Cobalt File Controller and Upload File
    		$uploadcontroller = new CobaltControllerFiles();
    		$uploadtask = $jinput->get('task', "upload", 'STR');
    		$uploadcontroller->execute($uploadtask);
    	
    		//Get the temp name of the uploaded file for record creation.
    		$jsonfilename = $uploadcontroller->tempname;
    	
    		//Get the filename for operation creation.
    		$jsonfilepath = JPATH_ROOT . DIRECTORY_SEPARATOR . 'uploads'. DIRECTORY_SEPARATOR . 'json' . DIRECTORY_SEPARATOR . date("Y-m") . DIRECTORY_SEPARATOR . $jsonfilename;
    	
    		//Get Contents of said file and put in a string.
    		$jsonfilecontents = file_get_contents( $jsonfilepath );
    	
    		//Decode the json file
    		$jsondata = json_decode($jsonfilecontents, true);
    	}

    	////////////Start the File Edit
    	////////////
    	
        $controller = new CobaltControllerForm();
        $jinput = JFactory::getApplication()->input;

		//DONT USE FORM DATA!
        $post_vars = file_get_contents("php://input");
	$data = array();
	parse_str($post_vars, $data);
     
	if (empty($data[id])) {
        }
        else{
        $_POST['jform']['id'] = $data[id];
	
        }
		
	if (empty($data[title])) {
        }
        else{
        $_POST['jform']['title'] = $data[title];
        }
		
	if (empty($data[environment])) {
        }
        else{
    	$_POST['jform']['fields'][26][0] = $data[environment];
        }
		
		if (empty($data[targetenvironment])) {
        }
        else{
    	$_POST['jform']['fields'][147][0] = $data[targetenvironment];
        }
		
		if (empty($data[type])) {
        }
        else{
    	 $_POST['jform']['fields'][75] = $data[type];
        }
		
		if (empty($data[description])) {
        }
        else{
    	 $_POST['jform']['fields'][5]  = $data[description];
        }
		
		if (empty($data[managedbygateway])) {
        }
        else{
		if ($data[managedbygateway] == "true")
		{
			 $_POST['jform']['fields'][145]  = true;
		}
		else
		{
			 $_POST['jform']['fields'][145]  = false;
		}
    	
        }
		
        
        //Fake Post Data
	$_POST['jform']['fields'][26][0] = "362";
        $_POST['jform']['ucatid'] = '0';
        //$_POST['jform']['fields'][145] = false;
        if(!empty($_FILES)) {
        	$_POST['jform']['fields'][23][0] = $jsonfilename;
        }
        $_POST['jform']['fields'][44] = '';
        $_POST['jform']['meta_descr'] = '';
        $_POST['jform']['meta_key'] = '';
        $_POST['jform']['meta_index'] = '';
        $_POST['jform']['alias'] = '';
        $_POST['jform']['ctime'] = '2014-11-17 21:47:11';
        $_POST['jform']['extime'] = '';
        $_POST['jform']['ftime'] = '';
        $_POST['jform']['langs'] = 'en-GB';
        $_POST['jform']['hidden'] = '0';
        $_POST['jform']['featured'] = '0';
        $_POST['jform']['user_id'] = '129';
        $_POST['jform']['archive'] = '0';
        $_POST['jform']['access'] = '6';
        $_POST['jform']['published'] = '1';
        $_POST['jform']['section_id'] = '2';
        $_POST['jform']['type_id'] = '2';
        //$_POST['jform']['fieldsdata'] = $description;

	
	
        $returnId = $this->update();
        /////////////////////////////
        ////Portal Event CURL CALL
        //
        //    'eventType' => 0,
        //    'id' => 0,
        //    'objectType' => 0,
        //    'userId' => 0,
        /////////////////////////////

        $url = 'http://localhost/api220/portalEvent';
        
        $managerdata = array(
        'eventType' => "Update",
        'id' => $idtoedit ? $idtoedit : $returnId,
        'objectType' => "API",
        'updatedFields' => array('name' => array( [0] => "Application Name {$title}"))
        );
        
        $curl = curl_init();
        
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_HTTPHEADER, 'Content-type: text/plain');
        curl_setopt($curl, CURLOPT_POSTFIELDS, $managerdata);
        
        $resp = curl_exec($curl);
        curl_close($curl);

        $response = $this->getDataById($returnId);
    
        $this->plugin->setResponse($data);    
        //$this->plugin->setResponse($response[0]);
    }
    
    public function encode($string,$key) {
        $key = sha1($key);
        $strLen = strlen($string);
        $keyLen = strlen($key);
        for ($i = 0; $i < $strLen; $i++) {
            $ordStr = ord(substr($string,$i,1));
            if ($j == $keyLen) { $j = 0; }
            $ordKey = ord(substr($key,$j,1));
            $j++;
            $hash .= strrev(base_convert(dechex($ordStr + $ordKey),16,36));
        }
        return $hash;
    }

    private function update(){
        $form = $_POST['jform'];
        if ( !$form ){
            return false;
        }
        $id = $form['id'];
        unset($form['id']);
        unset($form['section_id']);
        unset($form['type_id']);
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select( $db->quoteName(array('fields')) )
            ->from($db->quoteName('#__js_res_record'))
            ->where($db->quoteName('id').'='.$id)
            ->setLimit(1);
        $db->setQuery($query);
        $result = $db->loadResult();
        $fieldsArr = json_decode($result, true);
        foreach ( $form['fields'] as $col=>$val ){
            if ( $col === 14 )
                $val = array( array("url"=>$val) );
            else if ( $col === 13 )
                $val = array($val);
            $fieldsArr[$col] = $val;
        }
        $fieldsJson = json_encode($fieldsArr);
        $form['fields'] = $fieldsJson;
        foreach( $form as $col => $val ){
            $fields[] = $db->quoteName($col) . ' = ' . $db->quote($val);
        }
        $querys = $db->getQuery(true);
        $querys->update($db->quoteName('#__js_res_record'))->set($fields)->where( $db->quoteName('id') . ' = '.$id );

        $db->setQuery($querys);
        $result = $db->execute();
        if ( $result ) {
            $res = $this->uploadValue($id, $form['fields']);
        } else {
            return fasle;
        }
        return $id;
    }

    private function uploadValue($record_id, $fieldsJson){
        $fields = json_decode($fieldsJson);
        $db = JFactory::getDbo();
        foreach( $fields as $key => $val ) {
            if ( !empty( $val ) ) {
                if(is_array($val))
                    $val = $val[0];
                $db->setQuery('SELECT `id` FROM `#__js_res_record_values` WHERE `record_id` = '.$record_id.' AND `field_id` ='.$key);
                $id = $db->loadResult();
                if ( $id ) {
                    $query = $db->getQuery(true);
                    $query->update($db->quoteName('#__js_res_record_values'))->set(array($db->quoteName('field_value') . ' = ' . $db->quote($val)))->where($db->quoteName('record_id') . ' = ' . $id);
                    $db->setQuery($query);
                    $db->execute();
                } else {
                    $db->setQuery('SELECT `key`, `label`, `field_type` FROM `#__js_res_fields` WHERE `id`='.$key);
                    $field = $db->loadObject();
                    $query = $db->getQuery(true);
                    $columns = array('field_id', 'field_key', 'field_type', 'field_label', 'field_value', 'record_id', 'user_id', 'type_id', 'section_id','category_id','ip','ctime');
                    $values = array($key, $db->quote($field->key), $db->quote($field->field_type), $db->quote($val), $db->quote($field->label), $record_id, $_POST['jform']['user_id'], $_POST['jform']['type_id'], $_POST['jform']['section_id'], 0, $db->quote('::1'),$db->quote(date('Y-m-d H:i:s', time())));
                    $query->insert($db->quoteName('#__js_res_record_values'))->columns($db->quoteName($columns))->values(implode(',', $values));
                    $db->setQuery($query);
                    $db->execute();
                }
            }
        }
        return true;
    }

    private function getDataById($id){
        $api = new CobaltApi();
        $jinput = JFactory::getApplication()->input;


        if (empty($jinput->get('limit',"",'CMD'))) {
            $usersetlimit = 5;
        }
        else{
            $usersetlimit = $jinput->get('limit',"",'CMD');
        }

	    $environmentID = $id;
        if ( !empty( $environmentID ) ){
            $ids[] = $environmentID;
        }
	
        $data = $api->records(
            $section_id = 2,
            $view_what,
            $orderby,
            $type_ids = 2,
            $user_id,
            $category_id,
            $limit = $usersetlimit,
            //$limit,
            $template,
            $client,
            $client_id,
            $lang,
            $ids
        );
        return $data['list'];
    }
	
private function Authenticate()
	{
	    /////////////////////////////
      	////Login Event CURL CALL
      	//
      	
      	$check1 = $_SERVER['PHP_AUTH_USER'];
    	$check2 = $_SERVER['PHP_AUTH_PW'];
    	
    	$check1;
    	$check2;
    	
    	$credentials = array(
    			'username' => $check1,
    			'password' => $check2,
    	);
    	
    	$options = array();
    	$auth = & JAuthentication::getInstance();
    	$authorization = $auth->authenticate($credentials, $options);
    	
    	//set response
    	
    	if ($authorization->status != JAuthentication::STATUS_SUCCESS)
    	{
    		header('HTTP/1.1 400 Bad Request', true, 400);
    		$response = "{$username} cannot be logged on The password or username pair is not correct.";
    	}
    	
    	else
    	{
    		$date =& JFactory::getDate();
    		
    		$mainframe =& JFactory::getApplication('site');
    		$mainframe->initialise();
    		
    		$mainframe->login($credentials);
    		$token = bin2hex(openssl_random_pseudo_bytes(16));
    		$user = JFactory::getUser();
    		$idholder = $user->id;
    		return $idholder;
			}
	}

}

// End Class

