<?php
/**
 * @package	API
 * @version 1.5
 * @author 
 * @link 	
 * @copyright 
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 */

defined('_JEXEC') or die( 'Restricted access' );

jimport('joomla.plugin.plugin');

class PlgAPIWebservices extends ApiPlugin
{
	public function __construct()
	{
		parent::__construct();

		ApiResource::addIncludePath(dirname(__FILE__).'/apis');
                ApiResource::addIncludePath(dirname(__FILE__).'/login');
                ApiResource::addIncludePath(dirname(__FILE__).'/operations');
                ApiResource::addIncludePath(dirname(__FILE__).'/organizations');
                ApiResource::addIncludePath(dirname(__FILE__).'/plans');
                ApiResource::addIncludePath(dirname(__FILE__).'/products');
                ApiResource::addIncludePath(dirname(__FILE__).'/subscriptions');
                ApiResource::addIncludePath(dirname(__FILE__).'/environments');
                ApiResource::addIncludePath(dirname(__FILE__).'/applications');
                //Setting Access Level to Public
                


                
	}
}
