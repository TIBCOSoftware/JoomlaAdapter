<?php

// This is the "API" / Application Interface for the APIX Project
//

defined('_JEXEC') or die('Restricted access');
//Includes
require_once JPATH_ROOT . '/includes/defines.php';
require_once JPATH_ROOT . '/includes/framework.php';
require_once JPATH_ROOT . '/includes/api.php';

jimport('joomla.user.authentication');
jimport('joomla.application.component.controller');
jimport( 'joomla.session.session' );

class WebservicesApiResourceLogin extends ApiResource {


    //Get
    public function get() {
       
	   // Delete Old Key and Replace with New One
			$sql = "DELETE from #__restapitable ";
				
			$db =& JFactory::getDBO(); // Get the database object
			$db->setQuery($sql); //prepare the query
			$result3 = $db->query(); //do query

    	$response = "Logged Off";
     
    }

    public function checkRequiredParameters() {
    
    	if (($this->username == '') || ($this->password == ''))
    	{
    		header('HTTP/1.1 405 Bad Request', true, 405);
    		$response = "No Username and Password Dectected";
    	}
    }
    
    public function post() {
        
    	$jinput = JFactory::getApplication()->input;
    	
    	$username = $jinput->get('username', '', 'STRING');
    	$password = $jinput->get('password', '', 'STRING');
    	
    	$this->checkRequiredParameters();
    	
    	$credentials = array (
    			'username' => $username,
    			'password' => $password
    	);
    	
    	$options = array();
    	$auth = & JAuthentication::getInstance();
    	$authorization = $auth->authenticate($credentials, $options);
    	
    	//set response
    	
    	if ($authorization->status != JAuthentication::STATUS_SUCCESS)
    	{
    		header('HTTP/1.1 400 Bad Request', true, 400);
    		$response = "{$username} cannot be logged on The password or username pair is not correct.";
    	}
    	
    	else
    	{
    		$date =& JFactory::getDate();
    		
    		$mainframe =& JFactory::getApplication('site');
    		$mainframe->initialise();
    		
    		$mainframe->login($credentials);
    		$token = bin2hex(openssl_random_pseudo_bytes(16));
    		$user = JFactory::getUser();
    		$idholder = $user->id;
    		$this->id = $idholder;	
			 
    		$sql = "CREATE TABLE IF NOT EXISTS #__restapitable (id int(11), token varchar(30), timestamp int(11))";
    		
			$db =& JFactory::getDBO(); // Get the database object
			$db->setQuery($sql); //prepare the query
			$result1 = $db->query(); //do query

			//Check to see if ID is in DB
			$sql = "SELECT (id) FROM #__restapitable WHERE (id) LIKE '$idholder'";
			
			$db =& JFactory::getDBO(); // Get the database object
			$db->setQuery($sql); //prepare the query
			$db->query(); //do query
			$result2 = $db->loadResult();
			
			//If Yes
			if ($result2)
			{
			// Delete Old Key and Replace with New One
			$sql = "UPDATE #__restapitable SET token='$token' WHERE id ='$idholder'";
				
			$db =& JFactory::getDBO(); // Get the database object
			$db->setQuery($sql); //prepare the query
			$result3 = $db->query(); //do query
			
			$sql = "UPDATE #__restapitable SET timestamp='$date' WHERE id ='$idholder'";
			
			$db =& JFactory::getDBO(); // Get the database object
			$db->setQuery($sql); //prepare the query
			$db->query(); //do query
			
			//Reset TimeStamp
			} 
			
			// If No
			else
			{
		    	//Create TimeStamp & Insert DATA
			$sql = "INSERT INTO #__restapitable (id,token,timestamp) VALUES ('$idholder','$token','$date')";
				
			$db =& JFactory::getDBO(); // Get the database object
			$db->setQuery($sql); //prepare the query
			$result4 = $db->query(); //do query
			}

		    
		    
		    
			//Change this to a timer function.......Create Time Stamp.
			//$sql = "DELETE FROM #__restapitable";
		
			//$db =& JFactory::getDBO(); // Get the database object
			//$db->setQuery($sql); //prepare the query
			//$result2 = $db->query(); //do query

			header("HTTP/1.1 200 OK");
    		$response = "{$authorization->username} has been logged on with ID:{$idholder}";
    		$this->plugin->setResponse($response);
			//$response = $result2;
			//$response = $token;
    	
    	}
    	
    	
    	
        
    }
}// End Class

